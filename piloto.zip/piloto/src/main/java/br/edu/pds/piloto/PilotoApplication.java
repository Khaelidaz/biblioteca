package br.edu.pds.piloto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PilotoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PilotoApplication.class, args);
	}

}
