package br.edu.pds.piloto.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.pds.piloto.domains.Autor;



public interface AutorRepositorio extends JpaRepository<Autor, Long> {

}