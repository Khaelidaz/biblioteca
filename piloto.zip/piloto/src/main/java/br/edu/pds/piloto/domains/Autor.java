package br.edu.pds.piloto.domains;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="autores")
public class Autor {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @Column
	    @NotBlank(message = "Qual nome do Autor?")
	    private String nomedoautor;

	    @Column
	    @Length(min = 2, max = 6, message = "Qual a sigla da Editora")
	    private String siglaEditora;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getNome() {
			return nomedoautor;
		}

		public void setNome(String nomedoautor ) {
			this.nomedoautor = nomedoautor;
		}

		public String getSigla() {
			return siglaEditora;
		}

		public void setSigla(String siglaEditora) {
			this.siglaEditora = siglaEditora;
		}

		@Override
		public int hashCode() {
			return Objects.hash(id, nomedoautor, siglaEditora);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Autor other = (Autor) obj;
			return Objects.equals(id, other.id) && Objects.equals(nomedoautor, other.nomedoautor) && Objects.equals(siglaEditora, other.siglaEditora);
		}
	    
	    

}

